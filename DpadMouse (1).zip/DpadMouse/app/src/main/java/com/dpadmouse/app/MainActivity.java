package com.dpadmouse.app;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.provider.Settings;
import android.view.KeyEvent;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.TextView;

public class MainActivity extends Activity {

    private SharedPreferences prefs;
    private TextView status, speedLabel;
    private Button btnToggleKey, btnClickKey;

    private int dp(int v) {
        return (int) (v * getResources().getDisplayMetrics().density);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        prefs = getSharedPreferences(Prefs.NAME, MODE_PRIVATE);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(16), dp(16), dp(16), dp(16));
        ScrollView sv = new ScrollView(this);
        sv.addView(root);
        setContentView(sv);

        status = new TextView(this);
        status.setTextSize(18);
        root.addView(status);

        Button btnAcc = new Button(this);
        btnAcc.setText("Mở cài đặt Trợ năng (bật Dpad Mouse)");
        btnAcc.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS));
            }
        });
        root.addView(btnAcc);

        speedLabel = new TextView(this);
        speedLabel.setPadding(0, dp(16), 0, 0);
        root.addView(speedLabel);

        SeekBar seek = new SeekBar(this);
        seek.setMax(39); // tốc độ 1..40
        seek.setProgress(prefs.getInt(Prefs.SPEED, Prefs.DEF_SPEED) - 1);
        seek.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar s, int p, boolean user) {
                prefs.edit().putInt(Prefs.SPEED, p + 1).apply();
                refresh();
            }
            @Override public void onStartTrackingTouch(SeekBar s) { }
            @Override public void onStopTrackingTouch(SeekBar s) { }
        });
        root.addView(seek);

        btnToggleKey = new Button(this);
        btnToggleKey.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                captureKey(Prefs.KEY_TOGGLE, "Gán phím BẬT/TẮT con trỏ");
            }
        });
        root.addView(btnToggleKey);

        btnClickKey = new Button(this);
        btnClickKey.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                captureKey(Prefs.KEY_CLICK, "Gán phím CLICK");
            }
        });
        root.addView(btnClickKey);

        CheckBox rootBox = new CheckBox(this);
        rootBox.setText("Dùng quyền root để click (chạy được trong game)");
        rootBox.setChecked(prefs.getBoolean(Prefs.ROOT, false));
        rootBox.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override public void onCheckedChanged(CompoundButton b, boolean checked) {
                prefs.edit().putBoolean(Prefs.ROOT, checked).apply();
            }
        });
        root.addView(rootBox);

        TextView help = new TextView(this);
        help.setPadding(0, dp(16), 0, 0);
        help.setText("Cách dùng:\n"
                + "• Bật dịch vụ trong Cài đặt > Trợ năng > Dpad Mouse.\n"
                + "• Nhấn phím BẬT/TẮT (mặc định SELECT) để hiện/ẩn con trỏ.\n"
                + "• D-pad: di chuyển (giữ lâu sẽ nhanh dần).\n"
                + "• D-pad giữa hoặc A: click. X: click giữ.\n"
                + "• L1 / R1: cuộn lên / xuống.\n"
                + "• Nút B / Back / Home vẫn hoạt động bình thường.");
        root.addView(help);
    }

    @Override
    protected void onResume() {
        super.onResume();
        refresh();
    }

    private void refresh() {
        boolean on = CursorService.instance != null;
        status.setText(on ? "Dịch vụ: ĐANG CHẠY" : "Dịch vụ: CHƯA BẬT");
        speedLabel.setText("Tốc độ con trỏ: " + prefs.getInt(Prefs.SPEED, Prefs.DEF_SPEED));
        btnToggleKey.setText("Phím bật/tắt: "
                + KeyEvent.keyCodeToString(prefs.getInt(Prefs.KEY_TOGGLE, Prefs.DEF_TOGGLE))
                + "  (bấm để đổi)");
        btnClickKey.setText("Phím click: "
                + KeyEvent.keyCodeToString(prefs.getInt(Prefs.KEY_CLICK, Prefs.DEF_CLICK))
                + "  (bấm để đổi)");
    }

    private void captureKey(final String prefKey, String title) {
        CursorService.captureMode = true;
        AlertDialog.Builder bd = new AlertDialog.Builder(this);
        bd.setTitle(title);
        bd.setMessage("Hãy nhấn một phím trên tay cầm.\n(Nhấn Back để hủy)");
        bd.setOnKeyListener(new DialogInterface.OnKeyListener() {
            @Override
            public boolean onKey(DialogInterface dialog, int keyCode, KeyEvent event) {
                if (event.getAction() == KeyEvent.ACTION_DOWN && event.getRepeatCount() == 0) {
                    if (keyCode != KeyEvent.KEYCODE_BACK) {
                        prefs.edit().putInt(prefKey, keyCode).apply();
                    }
                    dialog.dismiss();
                }
                return true;
            }
        });
        bd.setOnDismissListener(new DialogInterface.OnDismissListener() {
            @Override
            public void onDismiss(DialogInterface dialog) {
                CursorService.captureMode = false;
                refresh();
            }
        });
        bd.show();
    }
}
