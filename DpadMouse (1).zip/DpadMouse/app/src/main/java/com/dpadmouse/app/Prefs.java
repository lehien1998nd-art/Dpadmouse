package com.dpadmouse.app;

import android.view.KeyEvent;

final class Prefs {
    static final String NAME = "dpadmouse";

    static final String KEY_TOGGLE = "toggle_key";
    static final String KEY_CLICK = "click_key";
    static final String SPEED = "speed";
    static final String ROOT = "use_root";

    // Mặc định: SELECT bật/tắt con trỏ, D-pad giữa (hoặc nút A) = click
    static final int DEF_TOGGLE = KeyEvent.KEYCODE_BUTTON_SELECT;
    static final int DEF_CLICK = KeyEvent.KEYCODE_DPAD_CENTER;
    static final int DEF_SPEED = 12;

    private Prefs() {}
}
