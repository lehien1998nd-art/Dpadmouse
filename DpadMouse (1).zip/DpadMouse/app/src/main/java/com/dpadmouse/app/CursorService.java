package com.dpadmouse.app;

import android.accessibilityservice.AccessibilityService;
import android.content.SharedPreferences;
import android.graphics.PixelFormat;
import android.graphics.Point;
import android.graphics.Rect;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.View;
import android.view.WindowManager;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;
import android.view.accessibility.AccessibilityWindowInfo;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

/**
 * Accessibility service: chặn phím D-pad, vẽ con trỏ lên trên mọi app,
 * và "click" vào control nằm dưới con trỏ.
 *
 * Phím (khi con trỏ đang BẬT):
 *   D-pad            : di chuyển con trỏ (giữ lâu = nhanh dần)
 *   D-pad giữa / A   : click
 *   X                : click giữ (long click)
 *   L1 / R1          : cuộn lên / xuống
 *   SELECT (đổi được): bật / tắt con trỏ
 */
public class CursorService extends AccessibilityService {

    /** MainActivity đặt true khi đang chờ người dùng nhấn phím để gán. */
    static volatile boolean captureMode = false;
    static volatile CursorService instance;

    private WindowManager wm;
    private CursorView cursorView;
    private WindowManager.LayoutParams lp;
    private SharedPreferences prefs;

    private boolean active = false;
    private int cx, cy;
    private int sw, sh;

    @Override
    protected void onServiceConnected() {
        super.onServiceConnected();
        instance = this;
        prefs = getSharedPreferences(Prefs.NAME, MODE_PRIVATE);
        wm = (WindowManager) getSystemService(WINDOW_SERVICE);
        updateScreenSize();
        cx = sw / 2;
        cy = sh / 2;

        cursorView = new CursorView(this);
        int size = (int) (30 * getResources().getDisplayMetrics().density);
        lp = new WindowManager.LayoutParams(
                size, size,
                WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                        | WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
                        | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN
                        | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                PixelFormat.TRANSLUCENT);
        lp.gravity = Gravity.TOP | Gravity.LEFT;
        lp.x = cx - cursorView.pad;
        lp.y = cy - cursorView.pad;
        cursorView.setVisibility(View.GONE);
        wm.addView(cursorView, lp);
    }

    @Override
    public boolean onUnbind(android.content.Intent intent) {
        removeCursor();
        return super.onUnbind(intent);
    }

    @Override
    public void onDestroy() {
        removeCursor();
        super.onDestroy();
    }

    private void removeCursor() {
        instance = null;
        try {
            if (wm != null && cursorView != null) wm.removeView(cursorView);
        } catch (Exception ignored) {
        }
        cursorView = null;
    }

    @Override
    public void onAccessibilityEvent(AccessibilityEvent event) { }

    @Override
    public void onInterrupt() { }

    // ------------------------------------------------------------------
    // Nhận phím
    // ------------------------------------------------------------------
    @Override
    protected boolean onKeyEvent(KeyEvent e) {
        if (captureMode || prefs == null || cursorView == null) return false;

        int code = e.getKeyCode();
        boolean down = e.getAction() == KeyEvent.ACTION_DOWN;
        boolean first = down && e.getRepeatCount() == 0;

        if (code == prefs.getInt(Prefs.KEY_TOGGLE, Prefs.DEF_TOGGLE)) {
            if (first) setActive(!active);
            return true;
        }
        if (!active) return false;

        int clickKey = prefs.getInt(Prefs.KEY_CLICK, Prefs.DEF_CLICK);
        if (code == clickKey || code == KeyEvent.KEYCODE_BUTTON_A) {
            if (first) click(false);
            return true;
        }

        switch (code) {
            case KeyEvent.KEYCODE_DPAD_UP:
                if (down) move(0, -step(e));
                return true;
            case KeyEvent.KEYCODE_DPAD_DOWN:
                if (down) move(0, step(e));
                return true;
            case KeyEvent.KEYCODE_DPAD_LEFT:
                if (down) move(-step(e), 0);
                return true;
            case KeyEvent.KEYCODE_DPAD_RIGHT:
                if (down) move(step(e), 0);
                return true;
            case KeyEvent.KEYCODE_BUTTON_X:
                if (first) click(true);
                return true;
            case KeyEvent.KEYCODE_BUTTON_L1:
                if (first) scroll(false);
                return true;
            case KeyEvent.KEYCODE_BUTTON_R1:
                if (first) scroll(true);
                return true;
            default:
                return false; // Back, Home, B... đi qua bình thường
        }
    }

    private int step(KeyEvent e) {
        int speed = prefs.getInt(Prefs.SPEED, Prefs.DEF_SPEED);
        float accel = 1f + Math.min(e.getRepeatCount(), 30) / 6f; // tối đa ~6 lần
        return Math.max(1, Math.round(speed * accel));
    }

    private void setActive(boolean on) {
        active = on;
        if (on) {
            updateScreenSize();
            cx = clamp(cx, 0, sw - 1);
            cy = clamp(cy, 0, sh - 1);
            applyPosition();
        }
        cursorView.setVisibility(on ? View.VISIBLE : View.GONE);
        Toast.makeText(this, on ? "Con trỏ: BẬT" : "Con trỏ: TẮT", Toast.LENGTH_SHORT).show();
    }

    private void move(int dx, int dy) {
        updateScreenSize();
        cx = clamp(cx + dx, 0, sw - 1);
        cy = clamp(cy + dy, 0, sh - 1);
        applyPosition();
    }

    private void applyPosition() {
        lp.x = cx - cursorView.pad;
        lp.y = cy - cursorView.pad;
        wm.updateViewLayout(cursorView, lp);
    }

    private void updateScreenSize() {
        Point p = new Point();
        wm.getDefaultDisplay().getRealSize(p);
        sw = p.x;
        sh = p.y;
    }

    private static int clamp(int v, int lo, int hi) {
        return Math.max(lo, Math.min(hi, v));
    }

    // ------------------------------------------------------------------
    // Click / cuộn
    // ------------------------------------------------------------------
    private boolean rootMode() {
        return prefs.getBoolean(Prefs.ROOT, false);
    }

    private void click(boolean longClick) {
        cursorView.flash();

        if (rootMode()) {
            if (longClick) {
                shell("input swipe " + cx + " " + cy + " " + cx + " " + cy + " 800");
            } else {
                shell("input tap " + cx + " " + cy);
            }
            return;
        }

        AccessibilityNodeInfo n = nodeAt(cx, cy);
        for (AccessibilityNodeInfo p = n; p != null; p = p.getParent()) {
            boolean ok = longClick ? p.isLongClickable() : p.isClickable();
            if (ok) {
                p.performAction(longClick
                        ? AccessibilityNodeInfo.ACTION_LONG_CLICK
                        : AccessibilityNodeInfo.ACTION_CLICK);
                return;
            }
        }
        Toast.makeText(this, "Không có nút để bấm ở đây (game? hãy bật chế độ root)",
                Toast.LENGTH_SHORT).show();
    }

    private void scroll(boolean forward) {
        if (rootMode()) {
            int d = sh / 3;
            int y2 = forward ? cy - d : cy + d;
            shell("input swipe " + cx + " " + cy + " " + cx + " " + clamp(y2, 0, sh - 1) + " 300");
            return;
        }
        AccessibilityNodeInfo n = nodeAt(cx, cy);
        for (AccessibilityNodeInfo p = n; p != null; p = p.getParent()) {
            if (p.isScrollable()) {
                p.performAction(forward
                        ? AccessibilityNodeInfo.ACTION_SCROLL_FORWARD
                        : AccessibilityNodeInfo.ACTION_SCROLL_BACKWARD);
                return;
            }
        }
    }

    /** Node sâu nhất, đang hiển thị, chứa điểm (x, y) — ở cửa sổ trên cùng. */
    private AccessibilityNodeInfo nodeAt(int x, int y) {
        List<AccessibilityWindowInfo> ws = getWindows();
        if (ws != null && !ws.isEmpty()) {
            List<AccessibilityWindowInfo> sorted = new ArrayList<AccessibilityWindowInfo>(ws);
            Collections.sort(sorted, new Comparator<AccessibilityWindowInfo>() {
                @Override
                public int compare(AccessibilityWindowInfo a, AccessibilityWindowInfo b) {
                    return b.getLayer() - a.getLayer(); // layer cao (trên cùng) trước
                }
            });
            for (AccessibilityWindowInfo w : sorted) {
                if (w.getType() == AccessibilityWindowInfo.TYPE_ACCESSIBILITY_OVERLAY) continue;
                Rect wr = new Rect();
                w.getBoundsInScreen(wr);
                if (!wr.contains(x, y)) continue;
                AccessibilityNodeInfo root = w.getRoot();
                if (root == null) continue;
                AccessibilityNodeInfo n = deepest(root, x, y);
                if (n != null) return n;
            }
        }
        AccessibilityNodeInfo root = getRootInActiveWindow();
        return root == null ? null : deepest(root, x, y);
    }

    private AccessibilityNodeInfo deepest(AccessibilityNodeInfo n, int x, int y) {
        Rect r = new Rect();
        n.getBoundsInScreen(r);
        if (!r.contains(x, y)) return null;
        for (int i = n.getChildCount() - 1; i >= 0; i--) {
            AccessibilityNodeInfo c = n.getChild(i);
            if (c == null || !c.isVisibleToUser()) continue;
            AccessibilityNodeInfo d = deepest(c, x, y);
            if (d != null) return d;
        }
        return n;
    }

    // ------------------------------------------------------------------
    // Chế độ root: dùng lệnh "input" (chạy được cả trong game)
    // ------------------------------------------------------------------
    private void shell(final String cmd) {
        new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    Process p = Runtime.getRuntime().exec(new String[]{"su", "-c", cmd});
                    p.waitFor();
                } catch (Exception ignored) {
                }
            }
        }).start();
    }
}
